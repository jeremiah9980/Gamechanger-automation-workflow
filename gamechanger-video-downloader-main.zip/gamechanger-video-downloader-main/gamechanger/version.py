# -*- coding: utf-8 -*-
"""
Package version.
"""

__version__ = '2024.07.01'
